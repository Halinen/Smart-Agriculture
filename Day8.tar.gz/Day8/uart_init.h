#ifndef _UART_INIT_H_
#define _UART_INIT_H_

#include <termios.h>
//串口选择
#if 1
	#define UART_DEV  	"/dev/ttyUSB0"
#else
	#define UART_DEV  	"/dev/ttySAC2"
#endif
extern int uart_open(int *fd,char *port);
extern void uart_close(int fd);  
extern int uart_set(int fd,int speed,int flow_ctrl,int databits,int stopbits,int parity);
extern int uart_init(int fd);


#endif
