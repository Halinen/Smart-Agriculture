#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <gtk/gtk.h>
#include <time.h>
#include "sqlite3.h"
#include <pthread.h>

GtkWidget *window_log = NULL;
GtkWidget *window_home = NULL;
GtkWidget *window_info = NULL;

void *gtk_show(void *arg)
{
	window_log = gtk_window_new(GTK_WINDOW_TOPLEVEL);//登录界面
	gtk_widget_show_all(window_log);
	
}

void *get_card(void *arg)
{
	
	printf("card\n");
	
}

int main(int argc,char **argv)
{
	gtk_init(&argc, &argv);	
	pthread_t gtkShow,getCard;
	pthread_create(&gtkShow,NULL,gtk_show,NULL);
	pthread_create(&getCard,NULL,get_card,NULL);
	//while(1);
	gtk_main();
	return 0;
}
