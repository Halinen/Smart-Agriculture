#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <gtk/gtk.h>
#include <time.h>
#include "sqlite3.h"
#include <pthread.h>
#include "uart_init.h"
#include"sungtk_interface.h" 
#include <string.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <regex.h>


GtkWidget *window_log = NULL;
GtkWidget *window_home = NULL;
GtkWidget *window_user = NULL;
GtkWidget *window_showtemhum = NULL;
GtkWidget *window_useradd = NULL;
GtkWidget *window_userrm = NULL;
GtkWidget *window_userupdate = NULL;
GtkWidget *window_history = NULL;
GtkWidget *table = NULL;
GtkWidget *entry_id =NULL;
GtkWidget *entry_pwd =NULL;
GtkWidget *entry_id_add =NULL;
GtkWidget *entry_pwd_add =NULL;
GtkWidget *label_tem =NULL;
GtkWidget *label_hum = NULL;
sqlite3 * db;
char tem[10] ;
char hum[10] ;
int flag=0;

void set_label_font_size(GtkWidget *label, int size)
{
	PangoFontDescription *font;  	// 字体指针
	font = pango_font_description_from_string(""); //参数为字体名字，任意即可
	// #define PANGO_SCALE 1024
	pango_font_description_set_size(font, size*PANGO_SCALE);// 设置字体大小
	gtk_widget_modify_font(label, font);  // 改变label的字体大小
	pango_font_description_free(font);	  // 释放字体指针分配的空间
}


void enter_user()
{
	window_user = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	create_user_window();
	gtk_widget_show_all(window_user);
	//gtk_widget_hide_all(window_home);
}

void stop()

{
	flag=0;
}

void back(GtkWidget * tmp)
{
	gtk_widget_hide_all(window_showtemhum);
	gtk_widget_hide_all(window_user);
	gtk_widget_hide_all(window_useradd);
	gtk_widget_hide_all(window_userrm);
	gtk_widget_hide_all(window_userupdate);
	
	gtk_widget_hide_all(window_history);
}


void enter_temhum()
{
	flag = 1;
	window_showtemhum = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(window_showtemhum, 1024, 500);
	g_signal_connect(window_showtemhum, "destroy", G_CALLBACK(stop), NULL);
	gtk_window_set_position(GTK_WINDOW(window_showtemhum), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_showtemhum), table);//  加布局 
	
	label_tem = gtk_label_new("27");
	set_label_font_size(label_tem, 30);
	
	label_hum = gtk_label_new("79");
	set_label_font_size(label_hum, 30);
	gtk_window_set_resizable(GTK_WINDOW(window_showtemhum), FALSE); 
	GdkPixbuf *src = gdk_pixbuf_new_from_file("./pic/1112.jpg", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
	
	GtkWidget *label = gtk_label_new("温湿度控制中心");
	set_label_font_size(label, 40);
	gtk_label_set_markup(
	GTK_LABEL(label),
	"<span foreground='YellowGreen'font_desc='35'>温湿度控制中心</span>");
	gtk_window_set_resizable(GTK_WINDOW(window_home), FALSE); 
	GtkWidget *label1 = gtk_label_new("当前温度：");
	//set_label_font_size(label1, 30);
	gtk_label_set_markup(
	GTK_LABEL(label1),
	"<span foreground='YellowGreen'font_desc='30'>当前温度：</span>");
	GtkWidget *label2 = gtk_label_new("当前湿度：");
	//set_label_font_size(label2, 30);
	gtk_label_set_markup(
	GTK_LABEL(label2),
	"<span foreground='YellowGreen'font_desc='30'>当前湿度：</span>");
	GtkWidget *button1 = gtk_button_new_with_label("返回");
	GtkWidget *labelChild;
	PangoFontDescription *font;
	int fontSize = 25;
	font = pango_font_description_from_string("Sans");
	pango_font_description_set_size(font, fontSize * PANGO_SCALE);//设置字体大小
	labelChild = gtk_bin_get_child(GTK_WIDGET(button1));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='YellowGreen'>返回</span>");
	gtk_button_set_relief(GTK_BUTTON(button1),GTK_RELIEF_NONE);

	gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 4, 0, 2);
	gtk_table_attach_defaults(GTK_TABLE(table),label1, 2, 3, 2 , 3);
	gtk_table_attach_defaults(GTK_TABLE(table),label2, 2, 3, 3, 4);
	gtk_table_attach_defaults(GTK_TABLE(table),label_tem, 3, 4, 2, 3);
	gtk_table_attach_defaults(GTK_TABLE(table),label_hum, 3, 4, 3, 4);
	gtk_table_attach_defaults(GTK_TABLE(table),button1, 2, 4, 5, 6);
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);	

	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(back), window_showtemhum);
	gtk_widget_show_all(window_showtemhum);
}



int result_log(void *para,int ncolumn,char ** columnvalue,char *columnname[])
{
	
	int i;
	char nlable[100];
	if(ncolumn>0&&columnvalue[0]&&columnname[0]){
		gtk_widget_show_all(window_home);
		gtk_widget_hide_all(window_log);
	}	
	for(i = 0;i < ncolumn; i++)
	{
			
		printf("user:%s:%s\n",columnname[i],columnvalue[i]);
	}
	printf("===========================\n");
 
	
	
	return ;
}



int result_history(void *para,int ncolumn,char ** columnvalue,char *columnname[])
{
	GtkWidget *label ;
	int i;
	char nlable[100];
	
	for(i = 0;i < ncolumn; i++)
		for(i = 1;i < 5; i++)
		{	
			label = gtk_label_new(columnvalue[i]);
			gtk_table_attach_defaults(GTK_TABLE(table), label, 1, 2, i, i+1);
			printf("user:%s:%s\n",columnname[i],columnvalue[i]);
		}
	printf("===========================\n");
 
	
	
	return ;
}


int sql_useradd(void *para,int ncolumn,char ** columnvalue,char *columnname[])
{
	
	int ret;
	char sql[100];
	const char * id,*pwd;
	char *errmsg=NULL;
	id = gtk_entry_get_text(GTK_ENTRY(entry_id_add));// 获得文本内容
	pwd = gtk_entry_get_text(GTK_ENTRY(entry_pwd_add));// 获得文本内容
	sprintf(sql,"insert into user_info values('%s',%s);",id,pwd);
	ret = sqlite3_exec(db,sql,NULL,NULL,NULL);
	
	gtk_widget_hide_all(window_useradd);
	
	return ;
	
}

int sql_userrm(void *para,int ncolumn,char ** columnvalue,char *columnname[])
{
	
	int ret;
	char sql[100];
	const char * id,*pwd;
	char *errmsg=NULL;
	id = gtk_entry_get_text(GTK_ENTRY(entry_id_add));// 获得文本内容
	sprintf(sql,"delete from user_info where name='%s';",id);
	ret = sqlite3_exec(db,sql,NULL,NULL,NULL);
	
	gtk_widget_hide_all(window_userrm);
	
	return ;
	
}

int sql_userupdate(void *para,int ncolumn,char ** columnvalue,char *columnname[])
{
	
	int ret;
	char sql[100];
	const char * id,*pwd;
	char *errmsg=NULL;
	id = gtk_entry_get_text(GTK_ENTRY(entry_id_add));// 获得文本内容
	pwd = gtk_entry_get_text(GTK_ENTRY(entry_pwd_add));// 获得文本内容
	sprintf(sql,"update user_info set pwd = %s where name='%s';",pwd,id);
	ret = sqlite3_exec(db,sql,NULL,NULL,NULL);
	
	gtk_widget_hide_all(window_userupdate);
	
	return ;
	
}

void enter_menu()
{
	
	int ret;
	char sql[100];
	const char * id,*pwd;
	char *errmsg=NULL;
	id = gtk_entry_get_text(GTK_ENTRY(entry_id));// 获得文本内容
	pwd = gtk_entry_get_text(GTK_ENTRY(entry_pwd));// 获得文本内容
	sprintf(sql,"select * from user_info where name = '%s' and pwd = %s;",id,pwd);
	ret = sqlite3_exec(db,sql,result_log,NULL,&errmsg);
	

	if(!ret)
	{
		printf("nono : %s\n",errmsg);
	}
	
	
}
void enter_useradd()
{
	window_useradd = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	create_useradd_window();
	gtk_widget_show_all(window_useradd);
	
}

void create_useradd_window()
{
	gtk_widget_set_size_request(window_useradd,1024, 500);
	//g_signal_connect(window_home, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_useradd), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_useradd), table);//  加布局 
	
	gtk_window_set_resizable(GTK_WINDOW(window_useradd), FALSE); 
	GdkPixbuf *src = gdk_pixbuf_new_from_file("wallhaven-4gj2q4.jpg", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
	
	GtkWidget *label = gtk_label_new("用户添加页面");
	GtkWidget *labe2 = gtk_label_new("请输入：");
	
	entry_id_add = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_id_add),"用户名");
	entry_pwd_add = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_pwd_add),"密码");	

	GtkWidget *button1 = gtk_button_new_with_label("确认添加");
	GtkWidget *button2 = gtk_button_new_with_label("返回");

	gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 4, 0, 1);
	//gtk_table_attach_defaults(GTK_TABLE(table), labe2, 2, 3, 3, 4);
	
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 2, 3, 4, 5);
	gtk_table_attach_defaults(GTK_TABLE(table), button2, 3, 4, 4, 5);

	gtk_table_attach_defaults(GTK_TABLE(table), entry_id_add, 2, 4, 2, 3);
	gtk_table_attach_defaults(GTK_TABLE(table), entry_pwd_add, 2, 4, 3, 4);
	
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);	
	//gtk_widget_show_all(window_home);
	g_signal_connect(G_OBJECT(button2), "clicked",G_CALLBACK(back), NULL);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(sql_useradd), NULL);
	
}

void create_userupdate_window()
{
	gtk_widget_set_size_request(window_userupdate, 1024, 500);
	//g_signal_connect(window_home, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_userupdate), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_userupdate), table);//  加布局 
	
	GtkWidget *label = gtk_label_new("密码修改页面");
	GtkWidget *labe2 = gtk_label_new("请输入：");
	
	GdkPixbuf *src = gdk_pixbuf_new_from_file("wallhaven-4gj2q4.jpg", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
	
	entry_id_add = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_id_add),"用户名");
	entry_pwd_add = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_pwd_add),"修改的密码");	

	GtkWidget *button1 = gtk_button_new_with_label("确认修改");

	gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 4, 0, 1);
	//gtk_table_attach_defaults(GTK_TABLE(table), labe2, 2, 3, 3, 4);

	GtkWidget *button2 = gtk_button_new_with_label("返回");
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 2, 3, 4, 5);
	gtk_table_attach_defaults(GTK_TABLE(table), button2, 3, 4, 4, 5);


	gtk_table_attach_defaults(GTK_TABLE(table), entry_id_add, 2, 4, 2, 3);
	gtk_table_attach_defaults(GTK_TABLE(table), entry_pwd_add, 2, 4, 3, 4);
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);
	
	//gtk_widget_show_all(window_home);
	g_signal_connect(G_OBJECT(button2), "clicked",G_CALLBACK(back), NULL);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(sql_userupdate), NULL);
	
}


void enter_userrm()
{
	window_userrm = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	create_userrm_window();
	gtk_widget_show_all(window_userrm);
	//gtk_widget_hide_all(window_home);
}

void enter_userupdate()
{
	window_userupdate = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	create_userupdate_window();
	gtk_widget_show_all(window_userupdate);
	//gtk_widget_hide_all(window_home);
}



void enter_history()
{
	window_history = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	create_history_window();
	gtk_widget_show_all(window_history);
	//gtk_widget_hide_all(window_home);
}


void create_home_window()
{
	//创建窗口、布局、控件
	gtk_widget_set_size_request(window_home, 1024, 500);
	g_signal_connect(window_home, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_home), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_home), table);//  加布局 
	
	GtkWidget *label = gtk_label_new("大棚管理系统");
	//set_label_font_size(label, 50);	
	gtk_label_set_markup(
	GTK_LABEL(label),
	"<span foreground='grey'font_desc='50'>大棚管理系统</span>");
	gtk_window_set_resizable(GTK_WINDOW(window_home), FALSE); 
	GdkPixbuf *src = gdk_pixbuf_new_from_file("./pic/wallhaven-ox3gqm.png", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
		
	GtkWidget *button1 = gtk_button_new_with_label("查询当前温度湿度");
	GtkWidget *button2 = gtk_button_new_with_label("查询最近温度湿度");
	//GtkWidget *button3 = gtk_button_new_with_label("设置保护温度湿度");
	GtkWidget *button4 = gtk_button_new_with_label("管理工作人员账户");
	GtkWidget *labelChild;
	PangoFontDescription *font;
	int fontSize = 25;
	font = pango_font_description_from_string("Sans");
	pango_font_description_set_size(font, fontSize * PANGO_SCALE);//设置字体大小
	labelChild = gtk_bin_get_child(GTK_WIDGET(button1));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='YellowGreen'>查询当前温度湿度</span>");
	labelChild = gtk_bin_get_child(GTK_WIDGET(button2));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='YellowGreen'>查询最近温度湿度</span>");
	labelChild = gtk_bin_get_child(GTK_WIDGET(button4));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='YellowGreen'>管理工作人员账户</span>");
	
	gtk_button_set_relief(GTK_BUTTON(button1),GTK_RELIEF_NONE);
	gtk_button_set_relief(GTK_BUTTON(button2),GTK_RELIEF_NONE);
	//gtk_button_set_relief(GTK_BUTTON(button3),GTK_RELIEF_NONE);
	gtk_button_set_relief(GTK_BUTTON(button4),GTK_RELIEF_NONE);

	gtk_table_attach_defaults(GTK_TABLE(table),label, 1, 5, 0, 2);
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 2, 4, 2, 3);

	gtk_table_attach_defaults(GTK_TABLE(table), button2, 2, 4, 3, 4);
	gtk_table_attach_defaults(GTK_TABLE(table), button4, 2, 4, 4, 5);
	//gtk_table_attach_defaults(GTK_TABLE(table), button4, 2, 4, 4, 5);
	
	
	//gtk_widget_show_all(window_home);
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(enter_temhum), NULL);
	g_signal_connect(G_OBJECT(button4), "clicked",G_CALLBACK(enter_user), NULL);
	g_signal_connect(G_OBJECT(button2), "clicked",G_CALLBACK(enter_history), NULL);

}



void create_user_window()
{
	gtk_widget_set_size_request(window_user, 1024, 500);
	//g_signal_connect(window_home, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_user), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_user), table);//  加布局 
	
	GtkWidget *label = gtk_label_new("用户管理页面");
		
	gtk_window_set_resizable(GTK_WINDOW(window_user), FALSE); 
	GdkPixbuf *src = gdk_pixbuf_new_from_file("wallhaven-4gj2q4.jpg", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
	
	GtkWidget *button1 = gtk_button_new_with_label("添加用户");
	GtkWidget *button2 = gtk_button_new_with_label("删除用户");
	GtkWidget *button3 = gtk_button_new_with_label("修改密码");

	gtk_button_set_relief(GTK_BUTTON(button1),GTK_RELIEF_NONE);
	gtk_button_set_relief(GTK_BUTTON(button2),GTK_RELIEF_NONE);
	gtk_button_set_relief(GTK_BUTTON(button3),GTK_RELIEF_NONE);
	GtkWidget *labelChild;
	PangoFontDescription *font;
	int fontSize = 25;
	font = pango_font_description_from_string("Sans");
	pango_font_description_set_size(font, fontSize * PANGO_SCALE);//设置字体大小
	labelChild = gtk_bin_get_child(GTK_WIDGET(button1));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='grey'>添加用户</span>");
	labelChild = gtk_bin_get_child(GTK_WIDGET(button2));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='grey'>删除用户</span>");
	labelChild = gtk_bin_get_child(GTK_WIDGET(button3));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='grey'>修改密码</span>");


	gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 4, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 2, 4, 1, 2);

	gtk_table_attach_defaults(GTK_TABLE(table), button2, 2, 4, 2, 3);
	gtk_table_attach_defaults(GTK_TABLE(table), button3, 2, 4, 3, 4);
	
	GtkWidget *button4 = gtk_button_new_with_label("返回");
	gtk_button_set_relief(GTK_BUTTON(button4),GTK_RELIEF_NONE);
	labelChild = gtk_bin_get_child(GTK_WIDGET(button4));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='grey'>返回</span>");
	gtk_table_attach_defaults(GTK_TABLE(table), button4, 2, 4, 4, 5);
	

	//gtk_widget_show_all(window_home);
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);	
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(enter_useradd), NULL);
	g_signal_connect(G_OBJECT(button2), "clicked",G_CALLBACK(enter_userrm), NULL);
	g_signal_connect(G_OBJECT(button3), "clicked",G_CALLBACK(enter_userupdate), NULL);
	g_signal_connect(G_OBJECT(button4), "clicked",G_CALLBACK(back), NULL);
	
}


void create_userrm_window()
{
	//创建窗口、布局、控件
	gtk_widget_set_size_request(window_userrm, 1024, 500);
	g_signal_connect(window_home, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_userrm), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_userrm), table);//  加布局 
	
	GtkWidget *label = gtk_label_new("请输入需要删除的用户名");
	gtk_window_set_resizable(GTK_WINDOW(window_userrm), FALSE); 
	GdkPixbuf *src = gdk_pixbuf_new_from_file("wallhaven-4gj2q4.jpg", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
	
	
	entry_id_add = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_id_add),"用户名");
	GtkWidget *button1 = gtk_button_new_with_label(" 确认删除");
	
	gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 4, 0, 1);
	GtkWidget *button2 = gtk_button_new_with_label("返回");
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 2, 3, 4, 5);
	gtk_table_attach_defaults(GTK_TABLE(table), button2, 3, 4, 4, 5);


	gtk_table_attach_defaults(GTK_TABLE(table), entry_id_add, 2, 4, 2, 3);
	
	
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);
	//gtk_widget_show_all(window_home);
	g_signal_connect(G_OBJECT(button2), "clicked",G_CALLBACK(back), NULL);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(sql_userrm), NULL);

}

void create_log_window()
{
	//创建窗口、布局、控件
	gtk_widget_set_size_request(window_log, 1024, 500);
	g_signal_connect(window_log, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_log), GTK_WIN_POS_CENTER);
	GtkWidget *table = gtk_table_new(12, 12, TRUE);
	gtk_container_add(GTK_CONTAINER(window_log), table);//  加布局 
	
	 
	gtk_window_set_resizable(GTK_WINDOW(window_log), FALSE); 
	GdkPixbuf *src = gdk_pixbuf_new_from_file("./pic/wallhaven-ox3gqm.png", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_two = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);
		
	
	GtkWidget *label = gtk_label_new("智慧农业监控");
	set_label_font_size(label, 50);
/*
这里foreground设置字体颜色
underline设置下划线
underline_color设置下划线颜色
*/
	gtk_label_set_markup(
	GTK_LABEL(label),
	"<span foreground='grey'font_desc='32'>智慧农业监控</span>");
	entry_id = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_id),"用户名");
	entry_pwd = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_pwd),"密码");
		
	gtk_entry_set_visibility(GTK_ENTRY(entry_pwd), FALSE);
	//GtkWidget *button1 = gtk_button_new_with_label("登录");
 	GtkWidget *button1 = sungtk_button_new_with_image("11.png", 164, 82); 
	/*gtk_button_set_relief(GTK_BUTTON(button1),GTK_RELIEF_NONE);

	GtkWidget *labelChild;
	labelChild = gtk_bin_get_child(GTK_WIDGET(button1));
	PangoFontDescription *font;
	int fontSize = 45;
	font = pango_font_description_from_string("Sans");//"Sans"字体
	pango_font_description_set_size(font, fontSize * PANGO_SCALE);//设置字体大小
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);*/

	gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 10, 0, 4);
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 5, 7, 9, 11);

	gtk_table_attach_defaults(GTK_TABLE(table), entry_id, 5, 7, 4, 6);
	gtk_table_attach_defaults(GTK_TABLE(table), entry_pwd, 5, 7, 6, 8);
		
	gtk_table_attach_defaults(GTK_TABLE(table),image_two, 0, 12, 0, 14);
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(enter_menu), NULL);
	gtk_widget_show_all(window_log);

}



void create_history_window()
{
	//创建窗口、布局、控件
	gtk_widget_set_size_request(window_history, 1024, 500);
	//g_signal_connect(window_history, "destroy", G_CALLBACK(gtk_main_quit), NULL);
	gtk_window_set_position(GTK_WINDOW(window_history), GTK_WIN_POS_CENTER);
	table = gtk_table_new(6, 6, TRUE);
	gtk_container_add(GTK_CONTAINER(window_history), table);//  加布局 
	
	//GtkWidget *label = gtk_label_new("历史温度湿度");
	GtkWidget *label;
	GtkWidget *label1 = gtk_label_new("温度");
	gtk_label_set_markup(
	GTK_LABEL(label1),
	"<span foreground='YellowGreen'font_desc='30'>温度</span>");
	GtkWidget *label2 = gtk_label_new("湿度");
	gtk_label_set_markup(
	GTK_LABEL(label2),
	"<span foreground='YellowGreen'font_desc='30'>湿度</span>");
	GdkPixbuf *src = gdk_pixbuf_new_from_file("22.jpg", NULL);
	GdkPixbuf *dst = gdk_pixbuf_scale_simple(src, 1024,500  ,GDK_INTERP_BILINEAR);
	GtkWidget *image_one = gtk_image_new_from_pixbuf(dst);
	g_object_unref(src);
        g_object_unref(dst);	
	
		
	
	GtkWidget *button1 = gtk_button_new_with_label("返回");
	gtk_button_set_relief(GTK_BUTTON(button1),GTK_RELIEF_NONE);
GtkWidget *labelChild;
	PangoFontDescription *font;
	int fontSize = 25;
	font = pango_font_description_from_string("Sans");
	pango_font_description_set_size(font, fontSize * PANGO_SCALE);//设置字体大小
	labelChild = gtk_bin_get_child(GTK_WIDGET(button1));//取出GtkButton里的label
	gtk_widget_modify_font(GTK_WIDGET(labelChild), font);
	gtk_label_set_markup(
	GTK_LABEL(labelChild),
	"<span foreground='YellowGreen'>返回</span>");


	//gtk_table_attach_defaults(GTK_TABLE(table),label, 2, 4, 0, 2);
	gtk_table_attach_defaults(GTK_TABLE(table), button1, 2, 4, 4, 5);

	gtk_table_attach_defaults(GTK_TABLE(table), label1, 0, 1, 0, 1);
	gtk_table_attach_defaults(GTK_TABLE(table), label2, 1, 2, 0, 1);
	
	g_signal_connect(G_OBJECT(button1), "clicked",G_CALLBACK(back), NULL);

	/*int ret;
	const char * id,*pwd;
	char *errmsg=NULL;
	char *sql="select * from temhum_info ";
	ret = sqlite3_exec(db,sql,result_history,NULL,NULL);*/
	char ** resultp;
	int nrow,ncolumn,i,j,index;
	char *sql="select * from temhum_info";

	if(sqlite3_get_table(db,sql,&resultp,&nrow,&ncolumn,NULL) != SQLITE_OK)
	{
		perror("sqlite3_get_table");
		exit(-1);
	}

	index = ncolumn;
	for(i = 0 ;i< ncolumn; i++)
		printf("%s\t",resultp[i]);
	printf("\n");

	for(i = 1;i< 5;i++)
	{
		for(j = 0;j< ncolumn;j++)
		{
			label = gtk_label_new(resultp[index]);
			set_label_font_size(label, 30);
			gtk_table_attach_defaults(GTK_TABLE(table), label, j, j+1, i, i+1);
	
			printf("%s\t",resultp[index++]);
		}
		printf("\n");
	}
	gtk_table_attach_defaults(GTK_TABLE(table),image_one, 0, 6, 0, 6);
}

void *gtk_show(void *arg)
{
	window_log = gtk_window_new(GTK_WINDOW_TOPLEVEL);//登录界面
	window_home = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	
	
	
	
	create_log_window();
	create_home_window();
	
	
	
	
	//create_temhumshow_window();
	
	gtk_main();
	
}

void sql_temhum(const char* tem1,const char *hum1)
{
	int ret;
	char sql[100];
	const char * id,*pwd;
	char *errmsg=NULL;
	
	sprintf(sql,"insert into temhum_info values('%s','%s')",tem1,hum1);
	ret = sqlite3_exec(db,sql,NULL,NULL,NULL);
	

	
	return ;
	
}

void * get_temhum(void *arg)
{
	int status ,i,j=0;
	int cflags = REG_EXTENDED;
	regmatch_t pmatch[1024];
	const size_t nmatch = 1024;
	regex_t reg;
	const char * pattern = ",(.{2}),";
	const char * pattern2 = ",.{2},(.{2}),";
	char * buf = "chenjiayi@126.com";
	char  tmp[5] = "";
	
		

	int zigbee_fd = 0;
	int ret;
	char date_buf[512] = "";
	zigbee_fd = open(UART_DEV, O_RDWR);
	printf("%d\n",zigbee_fd);
	/*if(uart_init(zigbee_fd) < 0)
	{
		printf("串口初始化失败\n");
		exit(-1);
	}*/

	
	while(1)
	{
		
		
		if(window_showtemhum&&flag==1){
		//sleep(0.5);
		ret = read(zigbee_fd, date_buf, sizeof(date_buf));
		if(ret < 0)
		{
			perror("read");
			return ;
		}
		
		printf("串口读到的数据为：%s\n",date_buf);
		
		//printf("%s",date_buf);
		buf = date_buf;
		//printf("buf:%s",buf);
		regcomp(&reg,pattern,cflags);
		regexec(&reg,buf,nmatch,pmatch,0);
		
		for(i = pmatch[0].rm_so+1;i<pmatch[0].rm_eo-1;++i){
					tmp[j]=buf[i];
					j++;
		}
		strcpy(tem,tmp);
		printf("\n%s\n",tem);
		char test[10] = "12312312";
		gtk_label_set_text(GTK_LABEL(label_tem),(gchar*)tmp);
		set_label_font_size(label_tem, 30);
	
		j=0;
		memset((char *)&tmp, 0, sizeof(tmp));
		regcomp(&reg,pattern2,cflags);
		regexec(&reg,buf,nmatch,pmatch,0);
		for(i = pmatch[0].rm_so+4;i<pmatch[0].rm_eo-1;++i){
					tmp[j]=buf[i];
					j++;
		}
		strcpy(hum,tmp);
		printf("/n%s/n",hum);
		
		gtk_label_set_text(GTK_LABEL(label_hum),(gchar*)tmp);
		set_label_font_size(label_hum, 30);
		j=0;
		memset((char *)&tmp, 0, sizeof(tmp));
		sql_temhum(tem,hum);

		//deal_str(date_buf);
		bzero(date_buf, sizeof(date_buf));
		}
		
	}
	regfree(&reg);
	close(zigbee_fd);
	return ;
	
}

sqlite3 * sql_open(){
	sqlite3 *db=NULL;
	int result=0;
	char *errmsg=NULL;
	result=sqlite3_open("shixun.db",&db);
	if(result!=SQLITE_OK)
	{
		printf("open error\n");
		return NULL;
	}
	else printf("succes");
	return (sqlite3 *)db;
}




int main(int argc,char **argv)
{
	gtk_init(&argc, &argv);	
	db = sql_open();
	pthread_t gtkShow,gettemhum;
	pthread_create(&gtkShow,NULL,gtk_show,NULL);
	pthread_create(&gettemhum,NULL,get_temhum,NULL);
	//while(1);
	void *retval,*retval1;
	pthread_join(gtkShow,&retval);
	pthread_join(gettemhum,&retval1);
	return 0;
}






