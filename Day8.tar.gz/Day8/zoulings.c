/*

编译：gcc sql.c sqlite3.c -o sql -lpthread -ldl `pkg-config --cflags --libs gtk+-2.0`　　//根据gtk版本和文件名
*/







#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>
#include "sqlite3.h"
#include <gtk/gtk.h>

//全局变量
sqlite3 *db;

GtkWidget *content_table;  //更新区
GtkWidget *label_ct;
GtkWidget *label_name_ct;
GtkWidget *label_grade_ct;

GtkWidget *id_entry;
GtkWidget *name_entry;
GtkWidget *grade_entry;

GtkWidget *delete_entry;

/*struct _GtkCombo { 
        GtkHBox hbox; 
        GtkWidget *entry; 
        GtkWidget *button;
        GtkWidget *popup; 
        GtkWidget *popwin; 
        GtkWidget *list;
	};*/

int getch();
void GUIview(int argc,char *argv[]);
void view(sqlite3 *db);
void selectView();
void createTable(sqlite3 *db);
void selectInfo(); //学生信息查询回调函数
int main(int argc,char *argv[])
{
	
	

	db =NULL;
	int result=0;
	result = sqlite3_open("stu_info.db",&db);
	if(result != SQLITE_OK)
	{
		printf("open error!\n");;
		return -1;
	}

	

	
	//创建表
	createTable(db);
	
	//界面
	//view(window);
	GUIview(argc, &argv);
	//view(db);
	

	
	sqlite3_close(db);
	return 0;
}

//学生数据查询回调
/*void selectInfo(GtkWidget *button, gpointer content_table)
{
	
	
	

	
}*/

//创建数据库表
void createTable(sqlite3 *db)
{
	char *errmsg =NULL;
	char *sql = "create table stu(id int,name text, grade int);";
	int ret = sqlite3_exec(db,sql,NULL,NULL,&errmsg);
	if(ret == SQLITE_OK)
	{
		printf("表创建成功");		
	}
}
//GUI


//entry_callback
void enter_callback_name(GtkWidget *Widget, gpointer get_entry ){
	char *errmsg =NULL;
	char *sql;
	char **resultp=NULL;
	int nrow;
	int ncolumn;
	
	
	char  *str = gtk_entry_get_text(GTK_ENTRY(get_entry));
	printf("%s",str);
	sql = sqlite3_mprintf("select * from stu where name= '%s';",str);
	//sql = sqlite3_mprintf("select * from stu;");  
	int ret = sqlite3_get_table(db,sql, &resultp,&nrow, &ncolumn, &errmsg); //非回调方法	
	char ct[ncolumn][200];
	printf("结果:%d\n",ret);
	if(ret == SQLITE_OK&&nrow>0){
		int i,j;
		int index = ncolumn;
		for(i=0;i<nrow;i++){
			for(j=0;j<ncolumn;j++){
				printf("====%s\n",resultp[index]);
				//gtk_label_set_text(GTK_LABEL(label_id_ct),resultp[index]);
				strcpy(ct[j],resultp[index]);
				
				//gtk_entry_set_text(get_entry,resultp[index]);
				index++;
			}
			printf("\n");
		}
		
		for(i=0;i<3;i++){
			printf("拆分:%s",ct[i]);
		}
		gtk_label_set_text(GTK_LABEL(label_ct),ct[0]);
		gtk_label_set_text(GTK_LABEL(label_name_ct),ct[1]);
		gtk_label_set_text(GTK_LABEL(label_grade_ct),ct[2]);
		
		
	}
	//getch();
	//sqlite3_exec(db,sql,selectback,NULL,&errmsg);	//回调方法
	//printf("%d,%d",nrow,ncolumn);
	
	//pause();
}

//GUIselectName
void GUIselectName(){
	GtkWidget *select_window_name = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(select_window_name), "学生信息查询");
	gtk_window_set_position(GTK_WINDOW(select_window_name),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(select_window_name,500,500);
	gtk_window_set_resizable(GTK_WINDOW(select_window_name),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(select_window_name),10);
	g_signal_connect(select_window_name,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	
	//
	GtkWidget *table = gtk_table_new(10,3,TRUE);
	GtkWidget *get_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(get_entry),"输入学生name");
	gtk_entry_set_max_length(GTK_ENTRY(get_entry),10);
	
	
	GtkWidget *label_id = gtk_label_new("id:");
	GtkWidget *label_name = gtk_label_new("name:");
	GtkWidget *label_grade = gtk_label_new("grade:");
	label_ct = gtk_label_new("1");
	label_name_ct = gtk_label_new("ZZZ");
	label_grade_ct = gtk_label_new("99");
	
	
	//
	gtk_container_add(GTK_CONTAINER(select_window_name),table);
	gtk_table_attach_defaults(GTK_TABLE(table),get_entry,0,3,0,1);
	gtk_table_attach_defaults(GTK_TABLE(table),label_id,0,1,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),label_name,1,2,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),label_grade,2,3,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),label_ct,0,1,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),label_name_ct,1,2,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),label_grade_ct,2,3,2,3);
	
	//
	
	
	//
	g_signal_connect(get_entry, "activate", G_CALLBACK(enter_callback_name), get_entry);
	
	//
	gtk_widget_show_all(select_window_name);
        gtk_main();
	
	
	
}
//enter_callback_id
void enter_callback_id(GtkWidget *Widget, gpointer get_entry){
	char *errmsg =NULL;
	char *sql;
	char **resultp=NULL;
	int nrow;
	int ncolumn;
	

	
	sql = sqlite3_mprintf("select * from stu where id= '%d';",atoi(gtk_entry_get_text(GTK_ENTRY(get_entry))));
	//sql = sqlite3_mprintf("select * from stu;");  
	int ret = sqlite3_get_table(db,sql, &resultp,&nrow, &ncolumn, &errmsg); //非回调方法	
	char ct[ncolumn][200];
	printf("结果:%d\n",ret);
	if(ret == SQLITE_OK&&nrow>0){
		int i,j;
		int index = ncolumn;
		for( i=0;i<nrow;i++){
			for(j=0;j<ncolumn;j++){
				printf("====%s\n",resultp[index]);
				//gtk_label_set_text(GTK_LABEL(label_id_ct),resultp[index]);
				strcpy(ct[j],resultp[index]);
				
				//gtk_entry_set_text(get_entry,resultp[index]);
				index++;
			}
			printf("\n");
		}
		for(i=0;i<3;i++){
			printf("拆分:%s",ct[i]);
		}
		gtk_label_set_text(GTK_LABEL(label_ct),ct[0]);
		gtk_label_set_text(GTK_LABEL(label_name_ct),ct[1]);
		gtk_label_set_text(GTK_LABEL(label_grade_ct),ct[2]);
		
		
	}
}

//GUIselectId
void GUIselectId(){

	GtkWidget *select_window_id = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(select_window_id), "学生信息查询");
	gtk_window_set_position(GTK_WINDOW(select_window_id),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(select_window_id,500,500);
	gtk_window_set_resizable(GTK_WINDOW(select_window_id),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(select_window_id),10);
	g_signal_connect(select_window_id,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	
	//
	GtkWidget *table = gtk_table_new(10,3,TRUE);
	GtkWidget *get_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(get_entry),"输入学生id");
	gtk_entry_set_max_length(GTK_ENTRY(get_entry),10);
	
	
	GtkWidget *label_id = gtk_label_new("id:");
	GtkWidget *label_name = gtk_label_new("name:");
	GtkWidget *label_grade = gtk_label_new("grade:");
	label_ct = gtk_label_new("1");
	label_name_ct = gtk_label_new("ZZZ");
	label_grade_ct = gtk_label_new("99");
	
	
	//
	gtk_container_add(GTK_CONTAINER(select_window_id),table);
	gtk_table_attach_defaults(GTK_TABLE(table),get_entry,0,3,0,1);
	gtk_table_attach_defaults(GTK_TABLE(table),label_id,0,1,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),label_name,1,2,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),label_grade,2,3,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),label_ct,0,1,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),label_name_ct,1,2,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),label_grade_ct,2,3,2,3);
	
	//
	
	
	//
	g_signal_connect(get_entry, "activate", G_CALLBACK(enter_callback_id), get_entry);
	
	//
	gtk_widget_show_all(select_window_id);
        gtk_main();
}

//查询弹窗
void selectInfo(GtkWidget *Widget, gpointer window){
	GtkWidget *select_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(select_window), "学生信息查询");
	gtk_window_set_position(GTK_WINDOW(select_window),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(select_window,500,500);
	gtk_window_set_resizable(GTK_WINDOW(select_window),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(select_window),200);
	g_signal_connect(select_window,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	
	
	//控件
	GtkWidget *vbox = gtk_vbox_new(TRUE,10);
	GtkWidget *button1 = gtk_button_new_with_label("按姓名查询");
	GtkWidget *button2 = gtk_button_new_with_label("按学号查询");
	
	
	//
	gtk_container_add(GTK_CONTAINER(select_window),vbox);
	gtk_container_add(GTK_CONTAINER(vbox),button1);
	gtk_container_add(GTK_CONTAINER(vbox),button2);
	
	//
	g_signal_connect(button1, "pressed", G_CALLBACK(GUIselectName), NULL);
	g_signal_connect(button2, "pressed", G_CALLBACK(GUIselectId), NULL);
	
	
	//gtk_widget_hide_all(window);
	gtk_widget_show_all(select_window);
        gtk_main();
}

//GUIinsert
void GUIinsert(GtkWidget *Widget, gpointer hint_label){
	int id;
	char name[20];
	int grade;
	char *errmsg =NULL;
	char *sql;
	
	//printf("请输入插入信息：\n");
	//printf("id\tname\tgrade\n");
	//scanf("%d%s%d",&id,name,&grade);
	sql = sqlite3_mprintf("insert into stu values(%d,'%s',%d);",atoi(gtk_entry_get_text(GTK_ENTRY(id_entry))),gtk_entry_get_text(GTK_ENTRY(name_entry)),atoi(gtk_entry_get_text(GTK_ENTRY(grade_entry))));
	int ret = sqlite3_exec(db,sql,NULL,NULL,&errmsg);
	if(ret == SQLITE_OK){
		gtk_label_set_text(GTK_LABEL(hint_label),"OK!");
	}
	else{
		gtk_label_set_text(GTK_LABEL(hint_label),"error!");
	}
	
}

//GUIreset
void GUIreset(){
	gtk_entry_set_text(GTK_ENTRY(id_entry),"请输入id");
	gtk_entry_set_text(GTK_ENTRY(name_entry),"请输入name");
	gtk_entry_set_text(GTK_ENTRY(grade_entry),"请输入grade");
}


//insertInfo
void insertInfo(){
	GtkWidget *insert_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(insert_window), "学生信息插入");
	gtk_window_set_position(GTK_WINDOW(insert_window),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(insert_window,300,300);
	gtk_window_set_resizable(GTK_WINDOW(insert_window),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(insert_window),10);
	g_signal_connect(insert_window,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	
	
	//
	GtkWidget *table = gtk_table_new(12,4,TRUE);
	GtkWidget *id = gtk_label_new("id");
	GtkWidget *name = gtk_label_new("name");
	GtkWidget *grade = gtk_label_new("grade");
	id_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(id_entry),"请输入id");
	name_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(name_entry),"请输入name");
	grade_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(grade_entry),"请输入grade");
	GtkWidget *hint_label = gtk_label_new("");
	GtkWidget *submit_button = gtk_button_new_with_label("提交");
	GtkWidget *reset_button = gtk_button_new_with_label("重置");
	
	
	//
	gtk_container_add(GTK_CONTAINER(insert_window),table);
	gtk_table_attach_defaults(GTK_TABLE(table),id,1,2,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),name,1,2,3,4);
	gtk_table_attach_defaults(GTK_TABLE(table),grade,1,2,4,5);
	gtk_table_attach_defaults(GTK_TABLE(table),reset_button,1,2,5,6);
	gtk_table_attach_defaults(GTK_TABLE(table),id_entry,2,3,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),name_entry,2,3,3,4);
	gtk_table_attach_defaults(GTK_TABLE(table),grade_entry,2,3,4,5);
	gtk_table_attach_defaults(GTK_TABLE(table),submit_button,2,3,5,6);
	gtk_table_attach_defaults(GTK_TABLE(table),hint_label,1,3,7,8);
	
	
	//信息绑定
	g_signal_connect(submit_button, "pressed", G_CALLBACK(GUIinsert), hint_label);
	g_signal_connect(reset_button, "pressed", G_CALLBACK(GUIreset), insert_window);
	
	
	
	//
	gtk_widget_show_all(insert_window);
        gtk_main();
}

//GUIupdate
void GUIupdate(){
	char *errmsg =NULL;
	char *sql;
	sql = sqlite3_mprintf("update stu set id=%d,name='%s', grade = %d where id = %d;",atoi(gtk_entry_get_text(GTK_ENTRY(id_entry))),gtk_entry_get_text(GTK_ENTRY(name_entry)),atoi(gtk_entry_get_text(GTK_ENTRY(grade_entry))), atoi(gtk_entry_get_text(GTK_ENTRY(id_entry))));
	sqlite3_exec(db,sql,NULL,NULL,&errmsg);
}

//update
void updateInfo(){
	GtkWidget *update_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(update_window), "学生信息更新");
	gtk_window_set_position(GTK_WINDOW(update_window),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(update_window,300,300);
	gtk_window_set_resizable(GTK_WINDOW(update_window),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(update_window),10);
	g_signal_connect(update_window,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	
	
	//
	GtkWidget *table = gtk_table_new(12,4,TRUE);
	GtkWidget *id = gtk_label_new("id");
	GtkWidget *name = gtk_label_new("name");
	GtkWidget *grade = gtk_label_new("grade");
	id_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(id_entry),"请输入id");
	name_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(name_entry),"请输入name");
	grade_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(grade_entry),"请输入grade");
	GtkWidget *submit_button = gtk_button_new_with_label("更新");
	GtkWidget *reset_button = gtk_button_new_with_label("重置");
	
	
	//
	gtk_container_add(GTK_CONTAINER(update_window),table);
	gtk_table_attach_defaults(GTK_TABLE(table),id,1,2,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),name,1,2,3,4);
	gtk_table_attach_defaults(GTK_TABLE(table),grade,1,2,4,5);
	gtk_table_attach_defaults(GTK_TABLE(table),reset_button,1,2,5,6);
	gtk_table_attach_defaults(GTK_TABLE(table),id_entry,2,3,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),name_entry,2,3,3,4);
	gtk_table_attach_defaults(GTK_TABLE(table),grade_entry,2,3,4,5);
	gtk_table_attach_defaults(GTK_TABLE(table),submit_button,2,3,5,6);
	
	//信息绑定
	g_signal_connect(submit_button, "pressed", G_CALLBACK(GUIupdate), update_window);
	g_signal_connect(reset_button, "pressed", G_CALLBACK(GUIreset), update_window);
	
	
	
	//
	gtk_widget_show_all(update_window);
        gtk_main();
}

//GUIdelete
void GUIdelete(){
	//int id;
	char *errmsg =NULL;
	char *sql;
	//printf("请输入要删除的学生的id：");
	//scanf("%d",&id);
	sql = sqlite3_mprintf("delete from stu where id=%d;",atoi(gtk_entry_get_text(GTK_ENTRY(delete_entry))));
	//printf("%s",sql);
	sqlite3_exec(db,sql,NULL,NULL,&errmsg);	
}

//deleInfo
void deleteInfo(){
	GtkWidget *delete_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(delete_window), "学生信息删除");
	gtk_window_set_position(GTK_WINDOW(delete_window),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(delete_window,500,500);
	gtk_window_set_resizable(GTK_WINDOW(delete_window),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(delete_window),10);
	g_signal_connect(delete_window,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	
	//
	GtkWidget *table = gtk_table_new(12,4,TRUE);
	delete_entry = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(delete_entry),"请输入要删除学生的id");
	GtkWidget *delete_button = gtk_button_new_with_label("删除");
	
	//
	gtk_container_add(GTK_CONTAINER(delete_window),table);
	gtk_table_attach_defaults(GTK_TABLE(table),delete_entry,0,2,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),delete_button,2,3,2,3);
	
	//
	g_signal_connect(delete_button, "pressed", G_CALLBACK(GUIdelete), delete_window);
	
	//
	gtk_widget_show_all(delete_window);
        gtk_main();
}
//界面函数
void GUIview(int argc,char *argv[])
{

	gtk_init(&argc, &argv);//初始化
	GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(window), "学生管理系统");
	gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
	gtk_widget_set_size_request(window,500,500);
	gtk_window_set_resizable(GTK_WINDOW(window),FALSE);
	gtk_container_set_border_width(GTK_CONTAINER(window),15);
	g_signal_connect(window,"destroy", G_CALLBACK(gtk_main_quit),NULL);
	//控件及设置
	
	//表格布局
	GtkWidget *table = gtk_table_new(6,10,TRUE);
	//label1
	GtkWidget *label = gtk_label_new("学生管理系统");
	//button options
	GtkWidget *button1= gtk_button_new_with_label("学生信息查询");
	GtkWidget *button2 = gtk_button_new_with_label("学生信息插入"); 
	GtkWidget *button3 = gtk_button_new_with_label("学生信息删除");
	GtkWidget *button4 = gtk_button_new_with_label("学生信息更新"); 
	//GtkWidget *button1_select = gtk_button_new_with_label("按学号查询");
	//GtkWidget *button2_select = gtk_button_new_with_label("按姓名查询");
	//GtkWidget*  gtk_combo_box_new_text();
	//content 表格布局
	
	//select_options
	
	

	//摆放控件
	gtk_container_add(GTK_CONTAINER(window), table);
	gtk_table_attach_defaults(GTK_TABLE(table),label,4,7,0,1);
	gtk_table_attach_defaults(GTK_TABLE(table),button1,4,7,1,2);
	gtk_table_attach_defaults(GTK_TABLE(table),button2,4,7,2,3);
	gtk_table_attach_defaults(GTK_TABLE(table),button3,4,7,3,4);
	gtk_table_attach_defaults(GTK_TABLE(table),button4,4,7,4,5);
	

	//button的回调
	g_signal_connect(button1, "pressed", G_CALLBACK(selectInfo), window);
	g_signal_connect(button2, "pressed", G_CALLBACK(insertInfo), window);
	g_signal_connect(button4, "pressed", G_CALLBACK(updateInfo), window);
	g_signal_connect(button3, "pressed", G_CALLBACK(deleteInfo), window);
	


	
	//控件摆放
	gtk_widget_show_all(window);
        gtk_main();
}

//回调函数
int selectback(void *para,int n_column, char **column_value, char **column_name){
	printf("\n查询结果是:\n");
	int i;
	for( i=0; i<n_column; i++){
		printf("%s\t",column_name[i]);
	}
	printf("\n");
	for( i=0; i<n_column;i++){
		printf("%s\t",column_value[i]);
	}
	printf("\n");
	getch();
	getch();
	return 0;
}
	
//nameSelect
void nameSelect(sqlite3 *db){
	char name[10];
	printf("请输入要查询的姓名：");
	scanf("%s",name);
	char *sql,*errmsg;
	sql = sqlite3_mprintf("select * from stu where name = '%s';",name);
	sqlite3_exec(db,sql,selectback,NULL,&errmsg);

}

//allselect
void allselect(sqlite3 *db){
	char *errmsg =NULL;
	char *sql;
	char **resultp=NULL;
	int nrow;
	int ncolumn;
	printf("全部学生信息：\n");
	sql = sqlite3_mprintf("select * from stu;");  
	int ret = sqlite3_get_table(db,sql, &resultp,&nrow, &ncolumn, &errmsg); //非回调方法	
	if(ret == SQLITE_OK){
		int i,j,k;
		int index = ncolumn;
		for(i=0;i<nrow;i++){
			for(j=0;j<ncolumn;j++){
				printf("%s\t",resultp[j]);
				
			
			}
			printf("\n");
			for( k=0;j<ncolumn;j++){
				printf("%s\t",resultp[index]);
				index++;
			}
			printf("\n");
		}
	}
	getch();
	//sqlite3_exec(db,sql,selectback,NULL,&errmsg);	//回调方法
	//printf("%d,%d",nrow,ncolumn);
	
	//pause();
}

//idselect
void idSelect(sqlite3 *db){
	int id;
	char *errmsg =NULL;
	char *sql;
	char **resultp=NULL;
	int nrow;
	int ncolumn;
	printf("请输入要查询的id号：");
	scanf("%d",&id);
	sql = sqlite3_mprintf("select * from stu where id= %d;",id);
	//sql = sqlite3_mprintf("select * from stu;");  
	int ret = sqlite3_get_table(db,sql, &resultp,&nrow, &ncolumn, &errmsg); //非回调方法	
	
	if(ret == SQLITE_OK){
		int i,j,k;
		int index = ncolumn;
		for( i=0;i<nrow;i++){
			for( j=0;j<ncolumn;j++){
				printf("%s\t",resultp[j]);
				
			
			}
			printf("\n");
			for(k=0;j<ncolumn;j++){
				printf("%s\t",resultp[index]);
				index++;
			}
			printf("\n");
		}
	}
	getch();
	//sqlite3_exec(db,sql,selectback,NULL,&errmsg);	//回调方法
	//printf("%d,%d",nrow,ncolumn);
	
	//pause();
}

//查询菜单
void slectMenu(sqlite3 *db){
	while(1){
		//system("clear");
		printf("*********学生管理系统*********\n*********1 按学号查询*********\n*********2 按学生姓名查询*********\n*********3 显示所有学生信息*********\n*********4 返回*********\n");
		int key;
		scanf("%d",&key);
		switch(key){
		case 1:idSelect(db);break;
		case 2:nameSelect(db);break;
		case 3:allselect(db);break;
		case 4:view(db);break;
		default:slectMenu(db);break;
		}
	}
	
	
}

//插入菜单
void insert(sqlite3 *db){
	int id;
	char name[20];
	int grade;
	char *errmsg =NULL;
	char *sql;
	printf("请输入插入信息：\n");
	printf("id\tname\tgrade\n");
	scanf("%d%s%d",&id,name,&grade);
	sql = sqlite3_mprintf("insert into stu values(%d,'%s',%d);",id,name,grade);
	sqlite3_exec(db,sql,NULL,NULL,&errmsg);	
}

//更新信息
void update(sqlite3 *db){
	int id;
	char name[20];
	int grade;
	char *errmsg =NULL;
	char *sql;
	printf("请输入要更新的信息：\n");
	printf("id\tname\tgrade\n");
	scanf("%d%s%d",&id,name,&grade);
	sql = sqlite3_mprintf("update  stu set id=%d,name='%s',grade=%d;",id,name,grade);
	sqlite3_exec(db,sql,NULL,NULL,&errmsg);	
}

//删除数据
void delete(sqlite3 *db){
	int id;
	char *errmsg =NULL;
	char *sql;
	printf("请输入要删除的学生的id：");
	scanf("%d",&id);
	sql = sqlite3_mprintf("delete from stu where id=%d;",id);
	printf("%s",sql);
	sqlite3_exec(db,sql,NULL,NULL,&errmsg);	
}

//首页
void view(sqlite3 *db)
{
	while(1){
		//system("clear");
		printf("*********学生管理系统*********\n*********1 学生信息查询*********\n*********2 学生信息插入*********\n*********3 学生信息更新*********\n*********4 学生信息删除*********\n*********５ 退出*********\n");
		int key;
		scanf("%d",&key);
		switch(key){
		case 1:slectMenu(db);break;
		case 2:insert(db);break;
		case 3:update(db);break;
		case 4:delete(db);break;
		case 5:exit(0);break;
		default:view(db);break;
		}
	}
	
}

//重写
int getch()
{
   struct termios tm, tm_old;
   int fd = STDIN_FILENO,c;
 
   if (tcgetattr(fd, &tm) < 0)
   {
      return -1;
   }
 
   tm_old = tm;
   cfmakeraw(&tm);
 
   if (tcsetattr(fd, TCSANOW, &tm) < 0)
   {
      return -1;
   }
 
   c = fgetc(stdin);
 
   if (tcsetattr(fd,TCSANOW,&tm_old) < 0)
   {
      return -1;
   }
 
   return c;
}





//回调方法：
/*	int sqlite3_exec(sqlite3 *db,		//数据库
			 const char *sql,  //sql语句
			 exechandler_t callback,	//回调函数(对有些操作是有用的)
			 void *arg,		//传给回调函数的值
			 char **errmsg);	//错误信息

	回调函数的格式：
			typedef int (*exechandler_t) (void *para,
							 int n_column,
							 char **column_value,
							 char **column_name)
*/


//非回调方法：

/*
		int sqlite3_get_table(sqlite3 *db,
					const char *sql,
					 char ***result,
					 int *nrow, int *ncolumn,
					  char **errmsg)













*/



































