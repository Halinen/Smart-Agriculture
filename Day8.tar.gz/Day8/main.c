#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "uart_init.h"

/*void deal_str(char *date_buf)
{
	char *p=NULL; 
	p = strtok(date_buf, ",");
	while(p)
	{  
		printf("%s\n", p);  
		p = strtok(NULL, ",");  
	}
	//保存到链表
		
}*/
int main(int argc,char *argv[])
{
	int zigbee_fd = 0;
	int ret;
	char date_buf[512] = "";
	zigbee_fd = open(UART_DEV, O_RDWR);
	printf("%d\n",zigbee_fd);
	if(uart_init(zigbee_fd) < 0)
	{
		printf("串口初始化失败\n");
		exit(-1);
	}
	while(1)
	{
		sleep(1);
		ret = read(zigbee_fd, date_buf, sizeof(date_buf));
		if(ret < 0)
		{
			perror("read");
			return -1;
		}
		printf("串口读到的数据为：%s\n",date_buf);
		//deal_str(date_buf);
		bzero(date_buf, sizeof(date_buf));
	}
	close(zigbee_fd);
	return 0;
}
